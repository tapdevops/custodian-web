# aWhere Code Samples

These code samples are designed to run "out of the box." We are building out code samples in multiple languages, so "watch" this repo for updates (or feel free to fork and contribute your own). 

## Help

If you need help with the code samples or the APIs, post a question in the [Community Q&A Forum](http://developer.awhere.com/forums). 